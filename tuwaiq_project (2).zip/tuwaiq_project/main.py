import cv2
import numpy as np

# المسارات كما طلبت
yolo_w = 'C:/Users/Administrator/Desktop/tuwaiq_project/yolov3.weights'
yolo_c = 'C:/Users/Administrator/Desktop/tuwaiq_project/yolov3.cfg'
coco_n = 'C:/Users/Administrator/Desktop/tuwaiq_project/coco.names'
image = 'C:/Users/Administrator/Desktop/tuwaiq_project/testimage.jpeg'

# تحميل أسماء الكائنات
with open(coco_n, 'r') as f:
    classes = f.read().strip().split('\n')

# تحميل الشبكة
net = cv2.dnn.readNet(yolo_w, yolo_c)

# محاولة تشغيل CUDA إذا كانت متاحة
try:
    net.setPreferableBackend(cv2.dnn.DNN_BACKEND_CUDA)
    net.setPreferableTarget(cv2.dnn.DNN_TARGET_CUDA)
except:
    print("CUDA غير متوفرة، سيتم استخدام CPU بدلاً منها.")

layer_names = net.getLayerNames()
out_layers = [layer_names[i - 1] for i in net.getUnconnectedOutLayers()]

# تحميل الصورة
img = cv2.imread(image)
h, w = img.shape[:2]

# معالجة الصورة وتمريرها عبر الشبكة
blob = cv2.dnn.blobFromImage(img, 1/255.0, (416, 416), swapRB=True, crop=False)
net.setInput(blob)
outputs = net.forward(out_layers)

# تحليل المخرجات
boxes, confidences, class_ids = [], [], []

for output in outputs:
    for detection in output:
        scores = detection[5:]
        class_id = np.argmax(scores)
        confidence = scores[class_id]
        if confidence > 0.5:
            center_x, center_y, width, height = (detection[:4] * [w, h, w, h]).astype("int")
            x = int(center_x - width / 2)
            y = int(center_y - height / 2)
            boxes.append([x, y, int(width), int(height)])
            confidences.append(float(confidence))
            class_ids.append(class_id)

# تطبيق NMS للتخلص من المربعات المتداخلة
indexes = cv2.dnn.NMSBoxes(boxes, confidences, score_threshold=0.5, nms_threshold=0.4)

if len(indexes) > 0:
    for i in indexes.flatten():
        x, y, w, h = boxes[i]
        label = f"{classes[class_ids[i]]}: {confidences[i]:.2f}"
        color = (0, 255, 0)
        cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
        cv2.putText(img, label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
else:
    print("لم يتم اكتشاف أي كائنات.")

# عرض الصورة
cv2.imshow("Result", img)
cv2.waitKey(0)
cv2.destroyAllWindows()

if __name__ == "__main__":
    print("تم تنفيذ الكود بنجاح!")
